#include<stdio.h>

void addition(int x,int y){

int p=10;
printf("Addition is %d",x+y);
}
