#include<stdio.h>
#include<string.h>
int main(){
char name[10]="AKADIR";
char x[10]=strlwr(name);
printf("%s",x);

return 0;
}
