int p=10;
