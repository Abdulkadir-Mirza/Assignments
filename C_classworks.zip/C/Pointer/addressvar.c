#include<stdio.h>
int main(){
int a=10, *ptr;
ptr=&a;
printf("%p",ptr);

return 0;
}
